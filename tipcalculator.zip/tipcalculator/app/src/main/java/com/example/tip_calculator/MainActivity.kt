package com.example.tip_calculator

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import com.example.tip_calculator.R.id.tips

class MainActivity : AppCompatActivity() {

    private lateinit var name: EditText
    private lateinit var seekBar: SeekBar
    private lateinit var percentage: TextView
    private lateinit var tips: TextView
    private lateinit var total: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById(R.id.name)
        seekBar = findViewById(R.id.seekBar)
        percentage = findViewById(R.id.percentage)
        tips = findViewById(R.id.tips)
        total = findViewById(R.id.total)

        addEditTextListener()
        addSeekBarListener()
    }

    private fun addEditTextListener(){
        name.addTextChangedListener(object :TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                Log.d("MainActivity", s?.toString() ?: "")

                computeTip()
            }
        })
    }

    private fun addSeekBarListener(){
       seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
           override fun onProgressChanged(seekBar: SeekBar?, progress: Int, frontUser: Boolean) {
               Log.d("Main Activity","$progress")

               percentage.text = "$progress"
               computeTip()
           }

           override fun onStartTrackingTouch(p0: SeekBar?) {
           }

           override fun onStopTrackingTouch(p0: SeekBar?) {
           }
       })
    }

    private fun computeTip(){
        val name = name.text.toString().toDoubleOrNull() ?: 0.0
        val percentage = seekBar.progress

        val tip = name * (percentage/100.0)
        val total = name + tip
        Log.d("Main Activity", "$tip")

        tips.text = "%.2f".format(tip)
       // total.text = "%.2f".format(total)
    }
}